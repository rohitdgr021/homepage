package com.example.homepage;

import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.VideoView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    public RecyclerView recyclerView;
    public Button btnCreate;
    public ImageButton download, btnLike, btnShare, btnComment, btnMusic, btnAccount;

    // Add your video resource IDs here
    private final int[] videoList = {R.raw.video};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new MyAdapter(videoList));

        download = findViewById(R.id.btndownload);
        btnCreate = findViewById(R.id.btnCreate);
        btnLike = findViewById(R.id.btnLike);
        btnShare = findViewById(R.id.btnShare);
        btnComment = findViewById(R.id.btnComment);
        btnMusic = findViewById(R.id.btnMusic);
        btnAccount = findViewById(R.id.btnAccount);

        btnCreate.setOnClickListener(v -> {
            // Handle button click for btnCreate
        });

        for (ImageButton imageButton : Arrays.asList(btnLike, btnShare, btnComment, btnMusic, btnAccount, download)) {
            imageButton.setOnClickListener(v -> {
                // Handle button clicks for other buttons
            });
        }
    }

    public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
        private final int[] videoList;

        public MyAdapter(int[] videoList) {
            this.videoList = videoList;
        }

        @NonNull
        @Override
        public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.video_item, parent, false);
            return new MyViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
            Uri videoUri = Uri.parse("android.resource://" + getPackageName() + "/" + videoList[position]);
            holder.videoView.setVideoURI(videoUri);
            holder.videoView.start();
        }

        @Override
        public int getItemCount() {
            return videoList.length;
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {
            VideoView videoView;

            public MyViewHolder(@NonNull View itemView) {
                super(itemView);
                videoView = itemView.findViewById(R.id.videoView);
            }
        }
    }
}
